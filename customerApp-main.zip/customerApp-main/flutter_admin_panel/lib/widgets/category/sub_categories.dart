import 'dart:html';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_admin_panel/services/firebase_services.dart';

class SubCategories extends StatefulWidget {
  final String catName;

  const SubCategories({this.catName});

  @override
  _SubCategoriesState createState() => _SubCategoriesState();
}

class _SubCategoriesState extends State<SubCategories> {
  @override
  Widget build(BuildContext context) {
    var _subCatNameController = TextEditingController();
    FirebaseServices _services = FirebaseServices();
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width * .32,
        child: Padding(
          padding: EdgeInsets.all(8),
          child: FutureBuilder<DocumentSnapshot>(
            future: _services.categories.doc(widget.catName).get(),
            builder: (BuildContext context,
                AsyncSnapshot<DocumentSnapshot> snapshot) {
              if (snapshot.hasError) {
                return Text("Something went wrong");
              }

              if (snapshot.connectionState == ConnectionState.done) {
                if (snapshot.hasError) {
                  return Text(
                    'No Sub-Categories Added Yet',
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 20,
                        color: Colors.teal),
                    textAlign: TextAlign.center,
                  );
                }
                Map<String, dynamic> data = snapshot.data.data();
                return Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Main Category  ',
                                  style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 22,
                                      color: Colors.teal),
                                  textAlign: TextAlign.center,
                                ),
                                Text(
// snapshot.data['subCat'][index]
                                  // data['subCat'][index]['name']
                                  snapshot.data['categoryName'],
                                  style: TextStyle(
                                      fontWeight: FontWeight.w800,
                                      fontSize: 22,
                                      color: Colors.teal),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                          Divider(
                            thickness: 3,
                            indent: 150,
                            endIndent: 150,

                          ),
                          //Categories list
                        ],
                      ),
                    ),
                    Container(
                      //Subcategories list
                      child: Expanded(
                        child: ListView.separated(
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          itemBuilder: (BuildContext context, int index) {
                            return ClipRRect(
                              borderRadius: BorderRadius.circular(
                                (30),

                              ),
                              child: ListTile(
                                trailing: CircleAvatar(
                                  backgroundColor:Colors.white,
                                  child: IconButton(
                                    icon: Icon(
                                      Icons.delete,
                                      color: Colors.red,
                                    ),
                                    onPressed: () {
                                      DocumentReference doc = _services.categories
                                          .doc(widget.catName);

                                      doc.update({
                                        'subCat': FieldValue.arrayRemove([
                                          {'name': data['subCat'][index]['name']}
                                        ]),
                                      });
                                      setState(() {});

                                      //   DocumentReference doc=_services.categories.doc(widget.catName).delete();

                                      //doc.delete();
                                    },
                                  ),
                                ),
                                horizontalTitleGap: 10,
                                tileColor: Colors.teal[50],
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(50),
                                    side: BorderSide.none),
                                contentPadding: EdgeInsets.all(10),
                                leading: CircleAvatar(
                                  backgroundColor: Colors.teal,
                                  child: Text('${index + 1}'),
                                ),
                                title: Text(data['subCat'][index]['name']),
                              ),
                            );
                          },
                          itemCount: data['subCat'] == null
                              ? 0
                              : data['subCat'].length,
                          separatorBuilder: (context, index) {
                            return Divider(
                              height: 3,

                              color: Colors.black26,
                            );
                          },
                        ),
                      ),
                    ),
                    Container(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Divider(
                              thickness: 3,
                              indent: 150,
                              endIndent: 150,
                              color: Colors.teal[50],
                            ),
                            Text(
                              'Add Sub Category',
                              style: TextStyle(
                                  color: Colors.teal,
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              children: [
                                Expanded(

                                    child: TextField(
                                      controller: _subCatNameController,
                                      decoration: InputDecoration(
                                        fillColor: Colors.white,
                                        filled: true,
                                        hintText: 'Please Write Sub-Category',
                                        contentPadding:
                                            EdgeInsets.only(left: 20),
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          borderSide: BorderSide(
                                              color: Colors.teal, width: 2),
                                        ),
                                        enabledBorder: const OutlineInputBorder(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(10)),
                                          borderSide: const BorderSide(
                                              color: Colors.teal, width: 2.0),
                                        ),
                                      ),
                                    )),
                                SizedBox(
                                  width: 5,
                                ),
                                // ignore: deprecated_member_use
                                FlatButton(
                                    padding: EdgeInsets.all(20),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                    onPressed: () {
                                      if (_subCatNameController.text.isEmpty) {
                                        return _services.showMyDialog(
                                            title: 'Category Alert',
                                            message:
                                                'Please Write Sub Category Name',
                                            context: context);
                                      }
                                      DocumentReference doc = _services
                                          .categories
                                          .doc(widget.catName);

                                      doc.update({
                                        'subCat': FieldValue.arrayUnion([
                                          {'name': _subCatNameController.text}
                                        ]),
                                      });
                                      setState(() {});
                                      _subCatNameController.clear();
                                    },
                                    color: Colors.teal,
                                    child: Text(
                                      'Add',
                                      style: TextStyle(color: Colors.white),
                                    )),
                                SizedBox(
                                  width: 10,
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              }

              return Center(
                child: CircularProgressIndicator(),
              );
            },
          ),
        ),
      ),
    );
  }
}

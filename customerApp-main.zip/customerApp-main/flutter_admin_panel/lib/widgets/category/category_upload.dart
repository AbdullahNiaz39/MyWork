import 'dart:html';

import 'package:ars_progress_dialog/ars_progress_dialog.dart';
import 'package:flutter/material.dart';
import 'package:firebase/firebase.dart' as db;
import 'package:flutter_admin_panel/services/firebase_services.dart';
class CategoryUploadImage extends StatefulWidget {
  @override
  _CategoryUploadImageState createState() => _CategoryUploadImageState();
}

class _CategoryUploadImageState extends State<CategoryUploadImage> {
  bool _visible = false;
  var _fileNameTextController = TextEditingController();
  var _categoryNameTextController = TextEditingController();
  bool _imageSelected = true;
  String _url;
  FirebaseServices _services=FirebaseServices();
  @override
  Widget build(BuildContext context) {
    ArsProgressDialog progressDialog = ArsProgressDialog(
      context,
      blur: 2,
      backgroundColor: Colors.teal.withOpacity(0.4),
      animationDuration: Duration(milliseconds: 1000),
    );
    return  Container(

      width: MediaQuery.of(context).size.width,
      height: 80,
      child: Row(
        children: [
          Visibility(
            visible: _visible,
            child: Row(
              children: [
                SizedBox(
                    width: 170,
                    child: TextField(
                      style: TextStyle(fontSize: 14),
                      controller: _categoryNameTextController,
                      decoration: InputDecoration(
                        fillColor: Colors.white,
                        filled: true,

                        hintText: 'Category Name',
                        contentPadding:
                        EdgeInsets.only(left: 10),
                        border: OutlineInputBorder(
                          borderRadius:
                          BorderRadius.circular(10),
                          borderSide: BorderSide(
                              color: Colors.teal, width: 2),
                        ),
                        enabledBorder: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10)),borderSide: const BorderSide(color: Colors.teal, width: 2.0),

                        ),
                      ),
                    )),
                SizedBox(width: 2,),
                AbsorbPointer(
                  absorbing: true,
                  child: SizedBox(
                      width: 170,
                      child: TextField(
                        style: TextStyle(fontSize: 12),
                        controller: _fileNameTextController,
                        decoration: InputDecoration(
                          fillColor: Colors.white,
                          filled: true,

                          hintText: 'No Image Category selected',
                          contentPadding:
                          EdgeInsets.only(left: 10),
                          border: OutlineInputBorder(
                            borderRadius:
                            BorderRadius.circular(10),
                            borderSide: BorderSide(
                                color: Colors.teal, width: 2),
                          ),
                          enabledBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),borderSide: const BorderSide(color: Colors.teal, width: 2.0),

                          ),
                        ),
                      )),
                ),
                // ignore: deprecated_member_use
                SizedBox(width: 2,),
                FlatButton(
                    padding: EdgeInsets.all(20),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    onPressed: () {
                      uploadInDb();
                    },
                    color: Colors.teal,
                    child: Text(
                      'Upload Category ',
                      style: TextStyle(color: Colors.white),
                    )),
                SizedBox(
                  width: 10,
                ),
                AbsorbPointer(
                  absorbing: _imageSelected,
                  child: FlatButton(
                      padding: EdgeInsets.all(20),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      onPressed: () {
                        if(_categoryNameTextController.text.isEmpty)
                          {
                            return _services.showMyDialog(title: 'Category Alert'
                                ,message: 'Please Write Category Name',
                              context: context
                            );
                          }
                        progressDialog.show();
                        _services.uploadImageToDBForCategory(_url,_categoryNameTextController.text).then((value){
                          progressDialog.dismiss();
                          _services.showMyDialog(
                              title: 'New Category Image',
                              context: context,
                              message: 'Saved Category Successfully'
                          );

                        });
                        _fileNameTextController.clear();
                        _categoryNameTextController.clear();
                      },
                      color: _imageSelected
                          ? Colors.teal[200]
                          : Colors.teal,
                      child: Text(
                        'Save Category',
                        style: TextStyle(color: Colors.white),
                      )),
                )
              ],
            ),
          ),
          SizedBox(
            width: 10,
          ),
          Visibility(
            visible: _visible ? false : true,
            child: FlatButton(
                padding: EdgeInsets.all(20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                onPressed: () {
                  setState(() {
                    _visible = true;
                  });
                },
                color: Colors.teal,
                child: Text(
                  'Add New Category',
                  style: TextStyle(color: Colors.white),
                )),
          )
          // ignore: deprecated_member_use
        ],
      ),
    );
  }
  void uploadImage({@required Function(File file) onSelected}) {
    InputElement uploadfile = FileUploadInputElement()
      ..accept = 'image/*'; //upload image
    uploadfile.click();
    uploadfile.onChange.listen((event) {
      final file = uploadfile.files.first;
      final reader = FileReader();
      reader.readAsDataUrl(file);
      reader.onLoadEnd.listen((event) {
        onSelected(file);
      });
    });
  }

  void uploadInDb() {
    final dateTime = DateTime.now();
    final path = 'CategoryImage/$dateTime';
    uploadImage(onSelected: (file) {
      if (file != null) {
        setState(() {
          _fileNameTextController.text = file.name;
          _imageSelected = false;
          _url= path;
        });
        db
            .storage()
            .refFromURL('gs://final-year-project-20566.appspot.com')
            .child(path)
             .put(file);
      }
    });
  }
}

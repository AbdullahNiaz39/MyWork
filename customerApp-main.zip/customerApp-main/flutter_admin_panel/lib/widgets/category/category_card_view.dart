import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_admin_panel/services/firebase_services.dart';
import 'package:flutter_admin_panel/widgets/category/sub_categories.dart';
import 'package:flutter_neumorphic/flutter_neumorphic.dart';

class CategoryCardView extends StatelessWidget {
  final DocumentSnapshot documentSnapshot;
  CategoryCardView(this.documentSnapshot);

  @override
  Widget build(BuildContext context) {
    FirebaseServices _services = FirebaseServices();

    return InkWell(
      onTap: () {
        showDialog(
            context: context,
            builder: (BuildContext context) {
              return Container(
                child: SubCategories(catName: documentSnapshot['categoryName']),
              );
            });
      },
      child: SizedBox(
        height: 220,
        width: 200,
        child: Neumorphic(
            style: NeumorphicStyle(
              shape: NeumorphicShape.convex,
              shadowLightColor: Colors.white,
              shadowDarkColor: Colors.grey,
              color: Colors.white,
              border: NeumorphicBorder(
                isEnabled: true,
              ),
              depth: 5,
              boxShape: NeumorphicBoxShape.roundRect(BorderRadius.circular(8)),
            ),
            child: Center(
              child: Column(
                children: [
                  Stack(children: [
                    SizedBox(
                      height: 160,
                      width: double.infinity,
                      child: new Card(
                        elevation: 8,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(15.0),
                            child: Image.network(
                              documentSnapshot['image'],
                              width: 300,
                              fit: BoxFit.fill,
                            )),
                      ),
                    ),
                    Positioned(
                        top: 10,
                        right: 10,
                        child: CircleAvatar(
                          backgroundColor: Colors.white,
                          child: IconButton(
                            onPressed: () {
                              _services.deleteDialogCategory(
                                  context: context,
                                  title: 'Delete Category',
                                  id: documentSnapshot.id,
                                  message: 'Are you sure you want to delete?');
                            },
                            icon: Icon(Icons.delete, color: Colors.red),
                          ),
                        ))
                  ]),
                  SizedBox(
                    height: 15,
                  ),
                  Text(
                    documentSnapshot['categoryName'],
                    style: TextStyle(
                        color: Colors.teal, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 20,
                  )
                ],
              ),
            )),
      ),
    );
  }
}

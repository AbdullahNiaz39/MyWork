import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_admin_panel/services/firebase_services.dart';
import 'package:flutter_admin_panel/widgets/category/category_card_view.dart';
class CategoryList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    FirebaseServices _services=FirebaseServices();
    return Container(
      width: MediaQuery.of(context).size.width,
      child: StreamBuilder(
        stream:_services.categories.snapshots(),
        builder: (BuildContext context,AsyncSnapshot<QuerySnapshot> snapShot){
      if(snapShot.hasError)
        {
          return Center(child: Text('Something Went Wrong'),);

        }
      if(snapShot.connectionState==ConnectionState.waiting)
      {
        return Center(child: CircularProgressIndicator(),);

      }
      return Wrap(
        spacing: 10,
        runSpacing: 10,
        direction: Axis.horizontal,
        children: snapShot.data.docs.map((DocumentSnapshot documentSnapshot){
          return CategoryCardView(documentSnapshot);
        }).toList()
      );
        },
      ),
    );
  }
}

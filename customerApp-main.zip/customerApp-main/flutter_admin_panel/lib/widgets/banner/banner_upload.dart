import 'dart:html';

import 'package:ars_progress_dialog/ars_progress_dialog.dart';
import 'package:flutter/material.dart';
import 'package:firebase/firebase.dart' as db;
import 'package:flutter_admin_panel/services/firebase_services.dart';
class BannerUploadImage extends StatefulWidget {
  @override
  _BannerUploadImageState createState() => _BannerUploadImageState();
}

class _BannerUploadImageState extends State<BannerUploadImage> {
  bool _visible = false;
  var _fileNameTextController = TextEditingController();
  bool _imageSelected = true;
  String _url;
  FirebaseServices _services=FirebaseServices();
  @override
  Widget build(BuildContext context) {
    ArsProgressDialog progressDialog = ArsProgressDialog(
      context,
      blur: 2,
      backgroundColor: Colors.teal.withOpacity(0.4),
      animationDuration: Duration(milliseconds: 1000),
    );
    return  Container(

      width: MediaQuery.of(context).size.width,
      height: 80,
      child: Row(
        children: [
          Visibility(
            visible: _visible,
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: AbsorbPointer(
                    absorbing: true,
                    child: SizedBox(
                        width: 300,
                        child: TextField(
                          controller: _fileNameTextController,
                          decoration: InputDecoration(
                            fillColor: Colors.white,
                            filled: true,
                            hintText: 'No Image Banner selected',
                            contentPadding:
                            EdgeInsets.only(left: 20),
                            border: OutlineInputBorder(
                              borderRadius:
                              BorderRadius.circular(10),
                              borderSide: BorderSide(
                                  color: Colors.teal, width: 2),
                            ),
                            enabledBorder: const OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(10)),borderSide: const BorderSide(color: Colors.teal, width: 2.0),

                            ),
                          ),
                        )),
                  ),
                ),
                // ignore: deprecated_member_use
                FlatButton(
                    padding: EdgeInsets.all(20),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    onPressed: () {
                      uploadInDb();
                    },
                    color: Colors.teal,
                    child: Text(
                      'Upload Banner',
                      style: TextStyle(color: Colors.white),
                    )),
                SizedBox(
                  width: 10,
                ),
                AbsorbPointer(
                  absorbing: _imageSelected,
                  child: FlatButton(
                      padding: EdgeInsets.all(20),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      onPressed: () {
                        progressDialog.show();
                        _services.uploadImageToDBForBanner(_url).then((value){
                          progressDialog.dismiss();
                          _services.showMyDialog(
                              title: 'New Banner Image',
                              context: context,
                              message: 'Saved Banner Successfully'
                          );

                        });
                        _fileNameTextController.clear();
                      },
                      color: _imageSelected
                          ? Colors.teal[200]
                          : Colors.teal,
                      child: Text(
                        'Save Banner',
                        style: TextStyle(color: Colors.white),
                      )),
                )
              ],
            ),
          ),
          SizedBox(
            width: 10,
          ),
          Visibility(
            visible: _visible ? false : true,
            child: FlatButton(
                padding: EdgeInsets.all(20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                onPressed: () {
                  setState(() {
                    _visible = true;
                  });
                },
                color: Colors.teal,
                child: Text(
                  'Add New Banner',
                  style: TextStyle(color: Colors.white),
                )),
          )
          // ignore: deprecated_member_use
        ],
      ),
    );
  }
  void uploadImage({@required Function(File file) onSelected}) {
    InputElement uploadfile = FileUploadInputElement()
      ..accept = 'image/*'; //upload image
    uploadfile.click();
    uploadfile.onChange.listen((event) {
      final file = uploadfile.files.first;
      final reader = FileReader();
      reader.readAsDataUrl(file);
      reader.onLoadEnd.listen((event) {
        onSelected(file);
      });
    });
  }

  void uploadInDb() {
    final dateTime = DateTime.now();
    final path = 'bannerImage/$dateTime';
    uploadImage(onSelected: (file) {
      if (file != null) {
        setState(() {
          _fileNameTextController.text = file.name;
          _imageSelected = false;
          _url= path;
        });
        db
            .storage()
            .refFromURL('gs://final-year-project-20566.appspot.com')
            .child(path)
             .put(file);
      }
    });
  }
}

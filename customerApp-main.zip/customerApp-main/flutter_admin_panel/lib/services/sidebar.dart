
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_admin_panel/screen/admin_users.dart';
import 'package:flutter_admin_panel/screen/banners_screen.dart';
import 'package:flutter_admin_panel/screen/categories_screen.dart';
import 'package:flutter_admin_panel/screen/home_screen.dart';
import 'package:flutter_admin_panel/screen/login_screen.dart';
import 'package:flutter_admin_panel/screen/notifications_screen.dart';
import 'package:flutter_admin_panel/screen/order_screen.dart';
import 'package:flutter_admin_panel/screen/setting_screen.dart';
import 'package:flutter_admin_panel/screen/vendors_screen.dart';
import 'package:flutter_admin_scaffold/admin_scaffold.dart';

class SidebarWidget{
  sideBarMenus(context,selectedRoute)
  {
    return SideBar(
      backgroundColor: Colors.teal,
      borderColor: Colors.teal[400],
      iconColor: Colors.white,
      activeTextStyle: TextStyle(color: Colors.white),
      activeBackgroundColor: Colors.teal[200],

      textStyle: TextStyle(color: Colors.white),
      items: const [
        MenuItem(
          title: 'Dashboard',

          route: HomeScreen.id,
          icon: Icons.dashboard,
        ),   MenuItem(

          title: 'Banners',
          route: BannerScreen.id,
          icon: CupertinoIcons.photo,
        ),
        MenuItem(

          title: 'Vendors',
          route: VendorScreen.id,
          icon: Icons.business_outlined

        ),   MenuItem(
          title: 'Orders',
          route: OrderScreen.id,
          icon: Icons.assignment,
        ),
        MenuItem(
          title: 'Categories',
          route: CategoryScreen.id,
          icon: Icons.apps,
        ),
        MenuItem(
          title: 'Notifications',
          route: NotificationScreen.id,
          icon: Icons.notification_important,
        ),
        MenuItem(
          title: 'Admin Users',
          route: AdminUserScreens.id,
          icon: Icons.group,
        ),
        MenuItem(
          title: 'Settings',
          route: SettingScreen.id,
          icon: Icons.settings,
        ),   MenuItem(
          title: 'Logout',
          route: LoginScreen.id,
          icon: Icons.logout,
        ),
      ],
      selectedRoute: selectedRoute,
      onSelected: (item) {
        Navigator.of(context).pushNamed(item.route);
      },
      header: Container(
        height: 50,
        width: double.infinity,
        color: Colors.teal,
        child: Center(
          child: Text(
            'DashBoard',
            style: TextStyle(
              color: Colors.white,
            ),
          ),
        ),
      ),
      footer: Container(
        height: 50,
        width: double.infinity,
        color: Colors.black26,
        child: Center(
          child: Text(
            'footer',
            style: TextStyle(
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
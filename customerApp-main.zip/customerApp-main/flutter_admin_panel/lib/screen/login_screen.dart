import 'package:ars_progress_dialog/ars_progress_dialog.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_admin_panel/screen/home_screen.dart';

import 'package:flutter_admin_panel/services/firebase_services.dart';

class LoginScreen extends StatefulWidget {
  static const String id='login-screen';
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();

  final _formkey = GlobalKey<FormState>();

  FirebaseServices _services = FirebaseServices();
  var _usernameTextEditorController = TextEditingController();
  var _passwordTextEditorController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    ArsProgressDialog progressDialog = ArsProgressDialog(
      context,
      blur: 2,
      backgroundColor: Colors.teal.withOpacity(0.4),
      animationDuration: Duration(milliseconds: 1000),
    );

    _login({username, password}) async {
      progressDialog.show();
      _services.getAdminCredentials(username).then((value) async {
        if (value.exists) {
          if (value.data()['username'] == username) {
            if (value.data()['password'] == password) {
              try {
                UserCredential userCredential =
                              await FirebaseAuth.instance.signInAnonymously();
                if (userCredential != null) {
                  progressDialog.dismiss();
                 Navigator.pushReplacementNamed(context,HomeScreen.id );

                }


              } catch (e) {
               progressDialog.dismiss();
               _services.showMyDialog(
                  context: context,
                    title: 'Login',
                    message: '${e.toString()}');
              }
              return;
            }
           progressDialog.dismiss();
            _services.showMyDialog(
                context: context,
                title: 'Invalid Password',
                message: 'The Password that you entered incorrect');
            return;
          }
          progressDialog.dismiss();
          _services.showMyDialog(
              context: context,
              title: 'Invalid Username',
              message: 'The username that you entered incorrect');
        }
        progressDialog.dismiss();
        _services.showMyDialog(
            context: context,
            title: 'Invalid Username',
            message: 'The username that you entered incorrect');
      });
    }

    //   progressDialog.show();
    //
    //   _services.getAdminCredentials().then((value) {
    //     value.docs.forEach((doc) async {
    //       if (doc.get('username') == username) {
    //         if (doc.get('password') == password) {
    //           progressDialog.dismiss();
    //           UserCredential userCredential =
    //               await FirebaseAuth.instance.signInAnonymously();
    //           if (userCredential.user.uid != null) {
    //             Navigator.pushReplacement(
    //                 context,
    //                 MaterialPageRoute(
    //                     builder: (BuildContext context) => HomeScreen()));
    //             return;
    //           } else {
    //             _showMyDialog(title: 'Login', message: 'Login Failed');
    //           }
    //         } else {
    //           progressDialog.dismiss();
    //           _showMyDialog(
    //               title: 'Invalid Username',
    //               message: 'The username that you entered incorrect ');
    //         }
    //       } else {
    //         progressDialog.dismiss();
    //         _showMyDialog(
    //             title: 'Invalid Username',
    //             message: 'The username that you entered incorrect ');
    //       }
    //     });
    //   });
    // }

    return Scaffold(
        // appBar: AppBar(
        //   centerTitle: true,
        //   elevation: 0,
        //   backgroundColor: Colors.teal,
        //   title: Text(
        //     'City Market App',
        //     style: TextStyle(fontWeight: FontWeight.w900, fontSize: 24),
        //   ),
        // ),
        body: FutureBuilder(
          future: _initialization,
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(
                child: Text('Error has been occured'),
              );
            }

            if (snapshot.connectionState == ConnectionState.done) {
              return Container(
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment(0.0, 0.0),
                        colors: [
                      Colors.teal,
                      Colors.teal[200],
                      Colors.teal[100],
                      Colors.white,
                    ],
                        stops: [
                      0.0,
                      1.0,
                      0.5,
                      1.0
                    ])),
                child: Center(
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20.0),
                        border: Border.all(color: Colors.teal, width: 2),
                        color: Colors.white),
                    width: 320,
                    height: 379,
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20.0)),
                      // elevation: 6,
                      // shape: Border.all(color: Colors.teal,width: 2),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Form(
                          key: _formkey,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Center(
                                child: SingleChildScrollView(
                                  child: Container(
                                    child: Column(
                                      children: [
                                        Image.asset(
                                          'images/logo.png',
                                          height: 100,
                                        ),
                                        Text(
                                          'Admin Login',
                                          style: TextStyle(
                                              fontWeight: FontWeight.w900,
                                              fontSize: 22),
                                        ),
                                        SizedBox(
                                          height: 30,
                                        ),
                                        TextFormField(
                                          controller:
                                              _usernameTextEditorController,
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              return 'Enter User name';
                                            }

                                            return null;
                                          },
                                          decoration: InputDecoration(
                                              hintText: 'UserName',
                                              labelText: 'UserName',
                                              focusColor: Colors.teal,
                                              contentPadding: EdgeInsets.zero,
                                              border: OutlineInputBorder(
                                                  borderSide: BorderSide(
                                                      color: Colors.teal),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          10)),
                                              prefixIcon:
                                                  Icon(Icons.account_circle)),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        TextFormField(
                                          controller:
                                              _passwordTextEditorController,
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              return 'Enter Password';
                                            }
                                            if (value.length < 6) {
                                              return 'Password must contain at least 6 characters';
                                            }

                                            return null;
                                          },
                                          obscureText: true,
                                          decoration: InputDecoration(
                                              hintText: 'Password',
                                              labelText: 'Password',
                                              focusColor: Colors.teal,
                                              contentPadding: EdgeInsets.zero,
                                              border: OutlineInputBorder(
                                                  borderSide: BorderSide(
                                                      color: Colors.teal),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          10)),
                                              prefixIcon: Icon(Icons.vpn_key)),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              // ignore: deprecated_member_use
                              Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  // ignore: deprecated_member_use
                                  child: FlatButton(
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                        side: BorderSide(color: Colors.teal)),
                                    onPressed: () async {
                                      if (_formkey.currentState.validate()) {

                                        _login(username: _usernameTextEditorController.text,password: _passwordTextEditorController.text);
                                        print('validated');
                                      }
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          left: 10,
                                          right: 10,
                                          bottom: 5,
                                          top: 5),
                                      child: Text(
                                        'Login',
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 18),
                                      ),
                                    ),
                                    color: Colors.teal,
                                  ))
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            }
            return Center(
              child: CircularProgressIndicator(),
            );
          },
        ));
  }


}

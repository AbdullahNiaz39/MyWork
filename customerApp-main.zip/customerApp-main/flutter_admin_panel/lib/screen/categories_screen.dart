import 'package:flutter/material.dart';
import 'package:flutter_admin_panel/services/sidebar.dart';
import 'package:flutter_admin_panel/widgets/category/category_list.dart';
import 'package:flutter_admin_panel/widgets/category/category_upload.dart';
import 'package:flutter_admin_scaffold/admin_scaffold.dart';

class CategoryScreen extends StatelessWidget {
  static const String id='category-screen';
  @override
  Widget build(BuildContext context) {
    SidebarWidget _sideBar=SidebarWidget();
    return AdminScaffold(

      backgroundColor: Colors.white,
      appBar: AppBar(
        title:Text('City Markets App'),
      ),
      sideBar:_sideBar.sideBarMenus(context, CategoryScreen.id),
      body: SingleChildScrollView(
        child: Container(
          alignment: Alignment.topLeft,
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Banner Screen',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 36,
                ),
              ),
              Text(
                'Add / Delete Home Screen Categories ',
                style: TextStyle(fontSize: 15, color: Colors.teal),
              ),
              Divider(
                thickness: 3,
                color: Colors.teal,
                endIndent: 400,
              ),
              SizedBox(
                height: 20,
              ),


             CategoryList(),
              SizedBox(
                height: 20,
              ),
              Divider(
                thickness: 3,
                color: Colors.teal,
                endIndent: 400,
              ),
              SizedBox(
                height: 20,
              ),
             // CategoryUploadImage(),
              CategoryUploadImage(),
            ],
          ),
        )
      ),
    );
  }
}

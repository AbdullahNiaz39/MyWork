import 'package:flutter/material.dart';
import 'package:flutter_admin_panel/services/sidebar.dart';
import 'package:flutter_admin_scaffold/admin_scaffold.dart';
class SettingScreen extends StatelessWidget {
  static const String id='setting-screen';
  @override
  Widget build(BuildContext context) {
    SidebarWidget _sideBar=SidebarWidget();
    return AdminScaffold(

      backgroundColor: Colors.white,
      appBar: AppBar(
        title:Text('City Markets App'),
      ),
      sideBar:_sideBar.sideBarMenus(context, SettingScreen.id),
      body: SingleChildScrollView(
        child: Container(
          alignment: Alignment.topLeft,
          padding: const EdgeInsets.all(10),
          child: Text(
            'Setting Screen',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 36,
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_admin_panel/services/sidebar.dart';
import 'package:flutter_admin_scaffold/admin_scaffold.dart';
class NotificationScreen extends StatefulWidget {
  static const String id='notification-screen';

  @override
  _NotificationScreenState createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  @override
  Widget build(BuildContext context) {
    SidebarWidget _sideBar=SidebarWidget();
    return AdminScaffold(

      backgroundColor: Colors.white,
      appBar: AppBar(
        title:Text('City Markets App'),
      ),
      sideBar:_sideBar.sideBarMenus(context, NotificationScreen.id),
      body: SingleChildScrollView(
        child: Container(
          alignment: Alignment.topLeft,
          padding: const EdgeInsets.all(10),
          child: Text(
            'Notification Screen',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 36,
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

const kpageviewText = TextStyle(
  fontSize: 20.0,
  fontWeight: FontWeight.w700,
);
const kApikey = 'AIzaSyDWlVd3X9_AofmiL75U-NUVD19Qsv11nNk';

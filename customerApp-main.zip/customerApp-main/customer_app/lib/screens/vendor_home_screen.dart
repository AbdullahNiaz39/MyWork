import 'package:customer_app/providers/vendor_provider.dart';
import 'package:customer_app/widgets/home_slider.dart';
import 'package:customer_app/widgets/vendor_banner.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
class VendorhomeScreen extends StatefulWidget {

  static const String id='vendorhome-screen';

  @override
  _VendorhomeScreenState createState() => _VendorhomeScreenState();
}

class _VendorhomeScreenState extends State<VendorhomeScreen> {
  @override
  Widget build(BuildContext context) {
    final _shopData=Provider.of<VendorProvider>(context);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(backgroundColor: Colors.teal,
     centerTitle: true,
        title: Text(_shopData.selectedVendor,style: TextStyle(fontWeight: FontWeight.bold),),
        actions: [
          IconButton(icon: Icon(CupertinoIcons.search), onPressed: (){})
        ],
        ),
        body: Column(
          children: [
            SizedBox(height:5 ,),
            VendorBanners(),
          ],
        ),
      ),
    );
  }
}

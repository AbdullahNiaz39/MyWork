import 'package:flutter/material.dart';

class FaverouiteScreen extends StatelessWidget {
  const FaverouiteScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Text('Faverouite Screen'),
      ),
    );
  }
}

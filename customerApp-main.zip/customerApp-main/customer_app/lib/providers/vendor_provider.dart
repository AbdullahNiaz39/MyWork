
import 'package:customer_app/services/shop_services.dart';
import 'package:customer_app/services/user_services.dart';
import 'package:flutter/cupertino.dart';

class VendorProvider with ChangeNotifier{
  ShopServices _shopServices=ShopServices();
  UserServices _userservices=UserServices();
  String selectedVendor;
  String selectedVendorId;
  getSelectedVendor(shopName,shopId)
  {
    this.selectedVendor=shopName;
    this.selectedVendorId=shopId;
    notifyListeners();
  }
}
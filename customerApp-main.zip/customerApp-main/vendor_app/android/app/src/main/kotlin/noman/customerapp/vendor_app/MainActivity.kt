package noman.customerapp.vendor_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

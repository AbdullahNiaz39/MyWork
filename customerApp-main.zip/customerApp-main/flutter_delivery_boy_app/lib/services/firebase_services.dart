

import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseServices{
  CollectionReference deliveryBoys=FirebaseFirestore.instance.collection('deliveryboys');
  Future <DocumentSnapshot> validateUser (id)async
  {
   DocumentSnapshot result= await deliveryBoys.doc(id).get();
    return result;
  }
}